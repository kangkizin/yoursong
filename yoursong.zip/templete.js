//templete.js

$(document).ready(function(){
	$(".loginbox").click(function(){
		$(".loginmodal").fadeIn();
	});
		
	$(".lomox").click(function(){
		$(".loginmodal").fadeOut();
	});


	$(".lomoclick2").click(function(){
		$(".loginmodal").fadeOut();
	});

	wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
	
});//doc