//index.js

$(document).ready(function(){
		alert("This site recommends using a chrome browser. - Creater KKJ");
	
		/*$(".header").hide();
		$(".sectiontext").hide();
		$(".downslidebox").hide();
		$(".navig").hide();
		$(".pic1").hide();
		$(".pic2").hide();
		$(".pic3").hide();
		$(".pic4").hide();
		$(".pic5").hide();
		$(".pic6").hide();
		$(".pic7").hide();
		$(".pic8").hide();
		$(".pic9").hide();
		$(".pic10").hide();
		$(".pic11").hide();*/
		$(".star").hide();
		$(".expo1").delay(100).fadeIn(1500);
		$(".expo2").delay(300).fadeIn(1500);
		$(".expo3").delay(500).fadeIn(1500);
		$(".expo4").delay(700).fadeIn(1500);
		$(".expo5").delay(900).fadeIn(1500);
		$(".expo6").delay(1100).fadeIn(1500);
		$(".expo7").delay(1300).fadeIn(1500);
		$(".expo8").delay(1500).fadeIn(1500);
		$(".expo9").delay(1700).fadeIn(1500);
		$(".expo0").delay(1900).fadeIn(1500, function(){
			$(".header").fadeIn(2000, function(){
				$(".expo, .loading").fadeOut(500, function(){
					$(".navig").fadeIn(500);
					
					$(".sectiontext").fadeIn(500, function(){
						$(".pic1").fadeIn(500);
						$(".pic2").delay(300).fadeIn(1000);
						$(".pic3").delay(500).fadeIn(1500);
						$(".pic4").delay(800).fadeIn(2000);
						$(".pic5").delay(1100).fadeIn(2500);
						$(".pic6").delay(1200).fadeIn(2000);
						$(".pic7").delay(1500).fadeIn(1500);
						$(".pic8").delay(1700).fadeIn(2000);
						$(".pic9").delay(1900).fadeIn(2000);
						$(".pic10").delay(1400).fadeIn(2000);
						$(".pic11").delay(700).fadeIn(2000);
						//$(".star").delay(2000).fadeIn();
						$(".downslidebox").delay(3500).fadeIn(2000);
					});
				});
			});
		});

		
		$(".navig>ul>li>a").click(function(e){
				$(".navig>ul>li>a").removeClass("on");
				$(this).addClass("on")

				href=$(this).attr("href");
				var scrt=$(href).offset().top;
				
				$("html, body").stop().animate({scrollTop:scrt},1100, "easeOutSine");
				e.preventDefault();
			});//nav a click

		$('.fullp').mousewheel(function(event, delta){
				if (delta>0)
				{
					//alert("UP");
					var sctt=$(this).prev().position().top;
				
					$("html, body").stop().animate({"scrollTop":sctt},1000,"swing");
				}else if (delta<0)
				{
					//alert("DOWN")
					var scyt=$(this).next().position().top;
				
					$("html, body").stop().animate({"scrollTop":scyt},1000,"swing");
				}//if
			});//section mousewheel

			


			$(window).scroll(function(){
				www=-400;
				h=$(window).height();//���������� ��ũ���̵� ���� ȭ�� ���̸� ����	
				scqt=$(window).scrollTop();//���������� ��ũ�ѹ��� ����� ��ġ���� ����
				
				for (var i=0; i<4 ;i++ )
				{
					if (scqt>=h*i+www && scqt<h*(i+1)+www)
						////(scrt>=i*h && scrt<(i+1)*h
					{
						$(".navig>ul>li>a").removeClass("on");
						$(".navig>ul>li>a").eq(i).addClass("on");
					}//if
				}//for
			});//window scroll

			/*$(window).resize(function(){
				www=-400;
				h=$(window).height();//���������� ��ũ���̵� ���� ȭ�� ���̸� ����	
				sctt=$(window).scrollTop();//���������� ��ũ�ѹ��� ����� ��ġ���� ����
				
				for (var i=0; i<4 ;i++ )
				{
					if (sctt>=h*i+www && sctt<h*(i+1)+www)
						////(scrt>=i*h && scrt<(i+1)*h
					{
						$(".navig>ul>li>a").removeClass("on");
						$(".navig>ul>li>a").eq(i).addClass("on");
					}//if
				}//for
			});*/

			/*$(window).resize(function(){//���������� ����� �ٲܶ� ����
			
				h=$(window).height()//�� �������� ����
				w=$(window).width()//�� �������� ����
					$('.fullp').css('height',h);
					console.log(h,w);
				
			$(window).scroll(function(){
				www=-400;
				h=$(window).height();//���������� ��ũ���̵� ���� ȭ�� ���̸� ����	
				sctt=$(window).scrollTop();//���������� ��ũ�ѹ��� ����� ��ġ���� ����
				
				for (var i=0; i<4; i++ )
				{
					if (sctt>=h*i+www && sctt<h*(i+1)+www)
						////(scrt>=i*h && scrt<(i+1)*h
					{
						$(".navig>ul>li>a").removeClass("on");
						$(".navig>ul>li>a").eq(i).addClass("on");
					}//if
				}//for
			});//window scroll

			$(".navig>ul>li>a").click(function(e){
				$(".navig>ul>li>a").removeClass("on");
				$(this).addClass("on")

				href=$(this).attr("href");
				 scrt=$(href).offset().top;
				console.log(href, scrt);
				$("html, body").stop().animate({scrollTop:scrt},1100, "swing");
				e.preventDefault();
			});//nav a click

		$('.fullp').mousewheel(function(event, delta){
				if (delta>0)
				{
					//alert("UP");
					scrt=$(this).prev().position().top;
					$("html, body").stop().animate({"scrollTop":scrt},1100,"swing");
				}else if (delta<0)
				{
					//alert("DOWN")
					scrt=$(this).next().position().top;
					$("html, body").stop().animate({"scrollTop":scrt},1100,"swing");
				}//if
			});//section mousewheel

		});//resize@@@@@@@@@@@@@@@@@@@@@22*/
	
	wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
/*----------------------�����̴�----------------------------------------------------*/
				//	var owl = $('.owl-carousel');
				//		owl.owlCarousel({
				//			items:5,
				//			loop:true,
				//			margin:0,
				//			autoplay:true,/*true*/
				//			autoplayTimeout:1500,
				//			autoplaySpeed:3500,
							/*slideTransition:String,*/
				//			autoplayHoverPause:false
							/*smartSpeed:3500*/
							/*fluidSpeed:Boolean*/
				//				});

				var owl = $('.owl-carousel');
					owl.owlCarousel({
						items:4,
						loop:true,
						margin:0,
						autoplay:true,
						autoplayTimeout:2500,
						autoplaySpeed:2500,
						autoplayHoverPause:false,
						smartSpeed:2500,
						responsive:{960:{items:5}},
						
					});


				
				$(".bigtext5>a").mouseenter(function(){
					
					$(".bigtext5>a>.headset").addClass("bounceIn");
				}).mouseleave(function(){
					$(".bigtext5>a>.headset").removeClass("bounceIn");
				});	
			
			$(".gothe").click(function(){
				var next=$("#sect3").position().top;
				$("html, body").stop().animate({"scrollTop":next},400,"swing");
			});
});//doc