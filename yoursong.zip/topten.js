//topten.js

$(document).ready(function(){
	$(".header").hide();
	$("#sect1").hide();
	$(".mtt1").delay(300).fadeIn();
	$(".mtt2").delay(600).fadeIn();
	$(".mtt3").delay(900).fadeIn();
	$(".mtt4").delay(1200).fadeIn();
	$(".mtt5").delay(1500).fadeIn();
	$(".mtt6").delay(1800).fadeIn();
	$(".mtt7").delay(2100).fadeIn(function(){
		$(".header").delay(500).fadeIn(function(){
			$(".toptenbg").delay(500).fadeOut(function(){
				$("#sect1").fadeIn();
			});
		});
	});

wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100,
        callback:     function(box) {
          console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
        }
      }
    );
    wow.init();
	var owl = $('.owl-carousel');
					owl.owlCarousel({
						items:1,
						loop:true,
						margin:0,
						autoplay:true,
						autoplayTimeout:3500,
						autoplaySpeed:3500,
						autoplayHoverPause:false,
						smartSpeed:3500
						
					});

			
		$(".navig>ul>li>a").click(function(e){
				$(".navig>ul>li>a").removeClass("on");
				$(this).addClass("on")

				var href=$(this).attr("href");
				var scrt=$(href).offset().top;
				console.log(href, scrt);
				$("html, body").stop().animate({scrollTop:scrt},500, "swing");
				e.preventDefault();
			});//nav a click

		$('.oop').mousewheel(function(event, delta){
				if (delta>0)
				{
					//alert("UP");
					var prev_pos=$(this).prev().position().top;
					$("html, body").stop().animate({"scrollTop":prev_pos},400,"swing");
				}else if (delta<0)
				{
					//alert("DOWN")
					var next_pos=$(this).next().position().top;
					$("html, body").stop().animate({"scrollTop":next_pos},400,"swing");
				}//if
			});//section mousewheel

			$(window).scroll(function(){
				www=-400;
				h=$(window).height();//브라우저에서 스크롤이동 전의 화면 높이를 구함	
				sctt=$(window).scrollTop();//브라우저에서 스크롤바의 꼭대기 위치값을 구함
				
				for (var i=0; i<11 ;i++ )
				{
					if (sctt>=h*i+www && sctt<h*(i+1)+www)
						////(scrt>=i*h && scrt<(i+1)*h
					{
						$(".navig>ul>li>a").removeClass("on");
						$(".navig>ul>li>a").eq(i).addClass("on");
					}//if
				}//for
			});//window scroll
});//doc