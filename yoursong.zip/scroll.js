//scroll.js


$(document).ready(function(){
	
		$(window).scroll(function(){

			$(".topkey").css({"display":"none"});
			var topvar=$(document).scrollTop(); 
			var dd=$(document).height();
			//console.log(topvar, dd);

			if (topvar>=750)
			{
				$(".topkey").css({"display":"block"});
			}else{
				$(".topkey").css({"display":"none"});
			}//if

//			$("html, body").animate({
//				scrollTop
//			},1000);
			if(topvar>=200)
			{
				$(".header").css({background:"rgba(155,174,200, 0.95 )"});
			}else if (topvar<200)
			{
				$(".header").css({background:"none"});
			}
	
		});//window scrollTop

		$(".topkey").click(function(){
			$("html, body").animate({
				scrollTop:0
			}, 1000,"easeInSine");
		});
	
		$(".menubar").click(function(){
			$(".mainmenu").fadeToggle(1000);	
			if ($(".menubar").hasClass("change"))
		{
			$(".header").css({background:"rgba(155,174,200, 1)",transition:"2.5s"});
		}else{
			$(".header").css({background:"none",transition:"0.5s"});
		}
		});

		

		

		
		
		

});//doc